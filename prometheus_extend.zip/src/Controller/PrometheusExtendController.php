<?php
/**
 * @file
 * Contains \Drupal\prometheus_extend\Controller\PrometheusExtendController.
 */

namespace Drupal\prometheus_extend\Controller;
use Drupal\Core\Controller\ControllerBase;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Serializer\SerializerInterface;
use PNX\Prometheus\Gauge;

/**
 * An example controller.
 */
class PrometheusExtendController extends ControllerBase {

 /**
   * The serializer.
   *
   * @var \Symfony\Component\Serializer\SerializerInterface
   */
  protected $serializer;

 /**
   * Constructs a ResourceResponseSubscriber object.
   *
   * @param \Symfony\Component\Serializer\SerializerInterface $serializer
   *   The serializer.
   *   The current route match.
   */
  public function __construct(SerializerInterface $serializer) {
    $this->serializer = $serializer;
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container) {
    return new static(
      $container->get('prometheus_extend.serializer')
    );
  }

  /**
   * Handles metrics requests.
   */
  public function content() {
    $output = [];
  	//Extra gauge added
  	$gauge = new Gauge("waltham_api_healthCheck", "gauge", "Monitors the health of the waltham");
  	$gauge->set(200, ['type' => 'http_status']);
  	$output[] = $this->serializer->serialize($gauge, 'prometheus');
    $response = new Response();
    $response->setMaxAge(0);
    $response->headers->set('Content-Type', 'text/plain; version=0.0.4');
    $response->setContent(implode($output));
    return $response;
  }
}
