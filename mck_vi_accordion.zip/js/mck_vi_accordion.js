/**
 * @file
 */

(function ($, Drupal, drupalSettings) {
  //var fields_content = $(this).parent('.accordion-wrap').children('.accordion-content ');
  $('.accordion-toggle').on('click', function () {
    var fields_content = $(this).parent('.accordion-wrap').children('.accordion-content');
    $("a.mck-icon--dark").removeClass("mck-icon__carrot-right").addClass("mck-icon__carrot-down");
    if (fields_content.is(':visible')) {
      fields_content.prev('.accordion-toggle').removeClass('active');
      $(this).find("a.mck-icon--dark").removeClass("mck-icon__carrot-right").addClass("mck-icon__carrot-down");
      fields_content.slideUp();
    } else {
      fields_content.prev('.accordion-toggle').addClass('active');
      $(this).find("a.mck-icon--dark").removeClass("mck-icon__carrot-down").addClass("mck-icon__carrot-right");
      fields_content.slideDown();
    }
    $('.accordion-content').not(fields_content).slideUp();
  });
})(jQuery, Drupal, drupalSettings);