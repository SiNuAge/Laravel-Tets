<?php

namespace Drupal\mck_vi_accordion\Plugin\views\style;

use Drupal\Core\Form\FormStateInterface;
use Drupal\views\Plugin\views\style\StylePluginBase;

/**
 * Style plugin for the cards view.
 *
 * @ingroup views_style_plugins
 *
 * @ViewsStyle(
 *   id = "mck_vi_accordion",
 *   title = @Translation("MCK VI Accordion"),
 *   help = @Translation("Displays content in VI Accordion View."),
 *   theme = "mck_vi_views_vi_accordion",
 *   display_types = {"normal"}
 * )
 */
class MckViAccordion extends StylePluginBase {
   /**
   * Does the style plugin allows to use style plugins.
   *
   * @var bool
   */
  protected $usesRowPlugin = TRUE;

  /**
   * Does the style plugin support custom css class for the rows.
   *
   * @var bool
   */
  protected $usesRowClass = FALSE;

  /**
   * Does the style plugin support grouping of rows.
   *
   * @var bool
   */
  protected $usesGrouping = FALSE;

  /**
   * Set default options.
   */
  protected function defineOptions() {
    $options = parent::defineOptions();
    $options['path'] = array('default' => 'mckviaccordion');
    return $options;
  }

  /**
   * Render the given style.
   */
  public function buildOptionsForm(&$form, FormStateInterface $form_state) {
    parent::buildOptionsForm($form, $form_state);
    $field_labels = $this->displayHandler->getFieldLabels(TRUE);
    $options = array('none' => "--None--") + $field_labels;

    $form['color'] = array(
      '#type' => 'select',
      '#title' => t('Color choose'),
      '#options' => [
        'bg-grey' => t('Grey'),
        'bg-white' => t('White'),
      ],
      '#default_value' => (isset($this->options['color'])? $this->options['color'] : $options['none']),
      '#description' => t("Select Color for the Accordian."),
    );

    $form['accordion'] = array(
      '#type' => 'select',
      '#title' => t('Accodian Option'),
      '#options' => [
        'plus-minus' => t('Plus Minus'),
        'up-down-arrow' => t('Up Down Arrow'),
      ],
      '#default_value' => (isset($this->options['accordion'])? $this->options['accordion'] : $options['none']),
      '#description' => t("Select Accordian for the Accordian."),
    );

    $form['title'] = array(
      '#type' => 'select',
      '#title' => t('Title/Subject'),
      '#options' => $options,
      '#default_value' => (isset($this->options['title'])? $this->options['title'] : $options['none']),
      '#description' => t("Title or Subject for the block."),
    );

    $form['content'] = array(
      '#type' => 'select',
      '#title' => t('Content'),
      '#options' => $options,
      '#default_value' => (isset($this->options['content'])? $this->options['content'] : $options['none']),
      '#description' => t("Select content."),
    );
  }
}