<?php

namespace Drupal\mck_uig_featured\Plugin\views\style;

use Drupal\Core\Form\FormStateInterface;
use Drupal\views\Plugin\views\style\StylePluginBase;

/**
 * Style plugin for the mck uig featured list.
 *
 * @ingroup views_style_plugins
 *
 * @ViewsStyle(
 *   id = "mck_uig_featured",
 *   title = @Translation("MCK UIG Featured List"),
 *   help = @Translation("Displays content in UIG Featured List."),
 *   theme = "mck_uig_featured",
 *   display_types = {"normal"}
 * )
 */
class MckUigFeatured extends StylePluginBase {
   /**
   * Does the style plugin allows to use style plugins.
   *
   * @var bool
   */
  protected $usesRowPlugin = TRUE;

  /**
   * Does the style plugin support custom css class for the rows.
   *
   * @var bool
   */
  protected $usesRowClass = FALSE;

  /**
   * Does the style plugin support grouping of rows.
   *
   * @var bool
   */
  protected $usesGrouping = FALSE;

  /**
   * Set default options.
   */
  protected function defineOptions() {
    $options = parent::defineOptions();
    $options['path'] = array('default' => 'mckuigfeatured');
    return $options;
  }

  /**
   * Render the given style.
   */
  public function buildOptionsForm(&$form, FormStateInterface $form_state) {
    parent::buildOptionsForm($form, $form_state);
    $field_labels = $this->displayHandler->getFieldLabels(TRUE);
    $options = array('none' => "--None--") + $field_labels;

    $form['layout'] = array(
      '#type' => 'select',
      '#title' => t('Layout'),
      '#options' => [
        'grid-row' => t('Row Layout'),
        'grid-col' => t('Column Layout'),
      ],
      '#default_value' => (isset($this->options['layout'])? $this->options['layout'] : $options['none']),
      '#description' => t("Select Layout for the view."),
    );
    $form['row_layout_type'] = array(
      '#type' => 'select',
      '#title' => t('Row Layout Type'),
      '#options' => [
        '' => t('--NONE'),
        'img-left' => t('Image on left'),
        'img-right' => t('Image on right'),
        'no-image' => t('Image Not Required')
      ],
      '#default_value' => (isset($this->options['row_layout_type'])? $this->options['row_layout_type'] : $options['none']),
      '#description' => t("Select Image position."),
    );
    $form['col_layout_type'] = array(
      '#type' => 'select',
      '#title' => t('Column Layout Type'),
      '#options' => [
        '' => t('--NONE'),
        'two-col' => t('Two Column Grid'),
        'two-col-grid' => t('Two Column'),
        'three-col' => t('Three Column'),
        'four-col' => t('Four Column'),
      ],
      '#default_value' => (isset($this->options['col_layout_type'])? $this->options['col_layout_type'] : $options['none']),
      '#description' => t("Select number of columns to come in layout."),
    );
    $form['url'] = array(
      '#type' => 'select',
      '#title' => t('URL'),
      '#options' => $options,
      '#default_value' => (isset($this->options['url'])? $this->options['url'] : $options['none']),
      '#description' => t("Select URL for the row."),
    );
    $form['title'] = array(
      '#type' => 'select',
      '#title' => t('Title'),
      '#options' => $options,
      '#default_value' => (isset($this->options['title'])? $this->options['title'] : $options['none']),
      '#description' => t("Select title."),
    );
    $form['image'] = array(
      '#type' => 'select',
      '#title' => t('Image'),
      '#options' => $options,
      '#default_value' => (isset($this->options['image'])? $this->options['image'] : $options['none']),
      '#description' => t("Select image."),
    );
    $form['description'] = array(
      '#type' => 'select',
      '#title' => t('Description'),
      '#options' => $options,
      '#default_value' => (isset($this->options['description'])? $this->options['description'] : $options['none']),
      '#description' => t("Select description."),
    );
    $form['meta'] = array(
      '#type' => 'select',
      '#title' => t('Meta'),
      '#options' => $options,
      '#default_value' => (isset($this->options['meta'])? $this->options['meta'] : $options['none']),
      '#multiple' => TRUE,
      '#description' => t("Select meta data for the list eg: date, tags, category"),
    );
    $form['likes'] = array(
      '#type' => 'select',
      '#title' => t('Like'),
      '#options' => $options,
      '#default_value' => (isset($this->options['likes'])? $this->options['likes'] : $options['none']),
      '#description' => t("Select like field, this field should return digit/number only."),
    );
    $form['comment'] = array(
      '#type' => 'select',
      '#title' => t('Comment'),
      '#options' => $options,
      '#default_value' => (isset($this->options['comment'])? $this->options['comment'] : $options['none']),
      '#description' => t("Select comment field, this field should return digit/number only."),
    );
  }

}
