<?php

namespace Drupal\mck_uig_profile\Plugin\views\style;

use Drupal\Core\Form\FormStateInterface;
use Drupal\views\Plugin\views\style\StylePluginBase;

/**
 * Style plugin for the cards view.
 *
 * @ingroup views_style_plugins
 *
 * @ViewsStyle(
 *   id = "mck_uig_profile",
 *   title = @Translation("MCK UIG Profile"),
 *   help = @Translation("Displays content in UIG Profile View."),
 *   theme = "mck_uig_profile_views_listing",
 *   display_types = {"normal"}
 * )
 */
class MckUigProfile extends StylePluginBase {
   /**
   * Does the style plugin allows to use style plugins.
   *
   * @var bool
   */
  protected $usesRowPlugin = TRUE;

  /**
   * Does the style plugin support custom css class for the rows.
   *
   * @var bool
   */
  protected $usesRowClass = FALSE;

  /**
   * Does the style plugin support grouping of rows.
   *
   * @var bool
   */
  protected $usesGrouping = FALSE;

  /**
   * Set default options.
   */
  protected function defineOptions() {
    $options = parent::defineOptions();
    $options['path'] = array('default' => 'mckuigprofile');
    return $options;
  }

  /**
   * Render the given style.
   */
  public function buildOptionsForm(&$form, FormStateInterface $form_state) {
    parent::buildOptionsForm($form, $form_state);
    $field_labels = $this->displayHandler->getFieldLabels(TRUE);
    $options = array('none' => "--None--") + $field_labels;
    $form['department'] = array(
      '#type' => 'select',
      '#title' => t('Department'),
      '#options' => $options,
      '#default_value' => (isset($this->options['department'])? $this->options['department'] : $options['none']),
      '#description' => t("Designation for the profile."),
    );
    $form['url'] = array(
      '#type' => 'select',
      '#title' => t('Profile URL'),
      '#options' => $options,
      '#default_value' => (isset($this->options['url'])? $this->options['url'] : $options['none']),
      '#description' => t("Select Profile URL for the row."),
    );
    $form['image'] = array(
      '#type' => 'select',
      '#title' => t('Image'),
      '#options' => $options,
      '#default_value' => (isset($this->options['image'])? $this->options['image'] : $options['none']),
      '#description' => t("Select image."),
    );
    $form['name'] = array(
      '#type' => 'select',
      '#title' => t('Name'),
      '#options' => $options,
      '#default_value' => (isset($this->options['name'])? $this->options['name'] : $options['none']),
      '#description' => t("Name for the profile."),
    );
    $form['designation'] = array(
      '#type' => 'select',
      '#title' => t('Designation'),
      '#options' => $options,
      '#default_value' => (isset($this->options['designation'])? $this->options['designation'] : $options['none']),
      '#description' => t("Designation for the profile."),
    );
    $form['description'] = array(
      '#type' => 'select',
      '#title' => t('Description'),
      '#options' => $options,
      '#default_value' => (isset($this->options['description'])? $this->options['description'] : $options['none']),
      '#description' => t("Select description."),
    );

  }

}


