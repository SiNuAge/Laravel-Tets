(function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);var f=new Error("Cannot find module '"+o+"'");throw f.code="MODULE_NOT_FOUND",f}var l=n[o]={exports:{}};t[o][0].call(l.exports,function(e){var n=t[o][1][e];return s(n?n:e)},l,l.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s})({1:[function(require,module,exports){
(function (global){
/**
 * @fileOverview jQuery flexbox carousel plugin.
 * @author Work & Co <info@work.co>
 * @version 1.0.0
 * @requires jQuery
 */

'use strict';

var $ = (typeof window !== "undefined" ? window['jQuery'] : typeof global !== "undefined" ? global['jQuery'] : null);

/**
 * Constructor for carousel jQuery plugin.
 * @constructor
 * @ignore
 * @param {jQuery} element jQuery to represent root element.
 * @param {object} options Plugin initialization options.
 * @see jQuery.fn.mckCarousel
 */
var Carousel = function (element, options) {
  this.$element = $(element);
  this.$carouselContainer = this.$element.find('.mck-carousel-wrap');

  this.options = $.extend({}, Carousel.DEFAULTS, options);

  this._initCarousel();

  // Event delegation for left arrow click
  this.$element.on(
    'click',
    this.options.prevSelector,
    this._previousElement.bind(this)
  );

  // Event delegation for right arrow click
  this.$element.on(
    'click',
    this.options.nextSelector,
    this._nextElement.bind(this)
  );
};

/**
 * Constructor initialization method. Calculates unit width, sets percentage
 *   based layout and applys flex rules.
 *   See {@link https://developer.mozilla.org/en-US/docs/Web/Guide/CSS/Flexible_boxes}
 *   for more more info on the use of flexbox layouts.
 * @private
 */
Carousel.prototype._initCarousel = function () {
  this.$carouselContainer.width(100 * this.$carouselContainer.children().length + '%'); // 300%
  var liSize = 100 / this.$carouselContainer.children().length; //33.333%

  this.$carouselContainer.children().each(function (index, element) {
    var $li = $(element);
    $li.css('flex', '0 0 ' + liSize + '%'); // set flex-basis
    $li.css('order', index); // give order
  });
};

/**
 * Transition to previous element from elment current displayed.
 * @param {jQuery.Event} evt jQuery click event.
 * @private
 */
Carousel.prototype._previousElement = function (evt) {
  var liSize = this.$element.width();

  var childrenLength = this.$carouselContainer.children().length;

  this.$carouselContainer.children().each(function () {
    var $currentElement = $(this);
    var currentOrder = parseInt(
      $currentElement.css('order'), 10
    );

    if (currentOrder === childrenLength - 1) {
      currentOrder = 0;
    } else {
      currentOrder = currentOrder + 1;
    }
    $currentElement.css('order', currentOrder);
  });
  this.$carouselContainer.css({
    marginLeft: -liSize
  });

  this.$carouselContainer.animate({
    marginLeft: 0
  }, this.options.animationDuration);

  evt.preventDefault();
};

/**
 * Transition to next element from elment current displayed.
 * @param {jQuery.Event} evt jQuery click event.
 * @private
 */
Carousel.prototype._nextElement = function (evt) {
  var liSize = this.$element.width();

  this.$carouselContainer.animate({
    marginLeft: ['-', liSize, 'px'].join('')
  }, this.options.animationDuration, function () {
    var childrenLength = this.$carouselContainer.children().length;
    this.$carouselContainer.children().each(function () {
      var $currentElement = $(this);
      var currentOrder = parseInt(
        $currentElement.css('order'), 10
      );
      if (currentOrder === 0) {
        currentOrder = childrenLength - 1;
      } else {
        currentOrder = currentOrder - 1;
      }
      $currentElement.css('order', currentOrder);
    });
    this.$carouselContainer.css({
      marginLeft: 0
    });

  }.bind(this));
  evt.preventDefault();
};

/**
 * Default plugin options.
 * @type {object}
 * @static
 */
Carousel.DEFAULTS = {
  animationDuration: 200,
  prevSelector: '[data-mck-carousel-prev]',
  nextSelector: '[data-mck-carousel-next]'
};

/**
 * A jQuery plugin that creates a flexbox-powered carousel,
 *   with next/previous controls.
 * @param {Object} [options] Plugin initialization options.
 * @param {string} [options.prevSelector=[data-mck-carousel-prev]]
 *        Selector to bind previous slide click functionality to.
 * @param {string} [options.nextSelector=[data-mck-carousel-next]]
 *        Selector to bind next slide click functionality to.
 * @param {number} [options.animationDuration=200]
 *        Slide animation speed (in miliseconds).
 *
 * @class mckCarousel
 * @memberOf jQuery.fn
 *
 * @example
 * $('.mck-carousel').mckCarousel({
 *   animationDuration: 100
 * });
 */
var Plugin = function(options) {
  options = ($.type(options) === 'object') ? options : {};

  return this.each(function () {
    var plugin = new Carousel(this, options);
    $(this).data('mckCarousel', plugin);
  });
};

// Extend jQuery with plugin
$.fn.mckCarousel = Plugin;
$.fn.mckCarousel.Constructor = Carousel;

}).call(this,typeof global !== "undefined" ? global : typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : {})
},{}]},{},[1]);
