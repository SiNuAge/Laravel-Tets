

(function($, Drupal) {
  $('.mck-carousel').mckCarousel();
  Drupal.behaviors.mck_uig_carousel = {
    attach: function (context, settings) {
    }
  };


})(jQuery, Drupal);
